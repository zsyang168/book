int bss_array[1024 * 1024];

int main(int argc, char* argv[])
{
	return 0;
}
