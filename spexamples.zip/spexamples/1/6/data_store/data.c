int data_array[1024 * 1024] = {1};

int main(int argc, char* argv[])
{
	return 0;
}
